package com.cg.bean;

public class Transaction {

	private int transId;
	private double transAmount;
	private String transType;
	private static int transCount = 100;
	
	public Transaction() {
		super();
		transId = Transaction.transCount++;
		transAmount = 0;
		transType = null;
	}
	public Transaction(double transAmount, String transType) {
		super();
		this.transAmount = transAmount;
		this.transType = transType;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public double getTransAmount() {
		return transAmount;
	}
	public void setTransAmount(double transAmount) {
		this.transAmount = transAmount;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public static int getTransCount() {
		return transCount;
	}
	public static void setTransCount(int transCount) {
		Transaction.transCount = transCount;
	}
	@Override
	public String toString() {
		return "Transaction [transId=" + transId + ", transAmount=" + transAmount + ", transType=" + transType + "]";
	}
	public void setTransDescription(String string) {
		// TODO Auto-generated method stub
		
	}
	
}
