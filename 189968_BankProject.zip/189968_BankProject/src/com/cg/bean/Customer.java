package com.cg.bean;

public class Customer {

	private String name;
	private String phoneNo;
	private String address;
	
	public Customer() {
		name = null;
		phoneNo = null;
		address = null;
	}

	public Customer(String name, String phoneNo, String address) {
		super();
		this.name = name;
		this.phoneNo = phoneNo;
		this.address = address;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", phoneNo=" + phoneNo + ", address=" + address + "]";
	}
	
}
