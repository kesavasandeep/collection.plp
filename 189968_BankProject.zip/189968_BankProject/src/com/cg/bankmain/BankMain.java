package com.cg.bankmain;

import java.util.Scanner;

import com.cg.exception.AccountNotFoundException;
import com.cg.exception.InsufficientAmountException;
import com.cg.service.ServiceImpl;

public class BankMain {
	static Scanner scan = new Scanner(System.in);
	public static void main(String[] args) {
		ServiceImpl serviceImpl = new ServiceImpl();
		int choice = 0;
		do{
			System.out.println("\n\n\n");
			System.out.println("**************************");
			System.out.println("Welcome to Capgemini Bank");
			System.out.println("1- Create New Account ");
			System.out.println("2- Show Balance");
			System.out.println("3- deposite");
			System.out.println("4- withdraw");
			System.out.println("5- fundTransfer");
			System.out.println("6- printTransaction");
			System.out.println("7- Exit");
			System.out.println("**************************");
			System.out.println("Enter a choice:");
			choice = Integer.parseInt(scan.nextLine());
			switch (choice){
			case 1:
				serviceImpl.CreateAccount();
				System.out.println("Account Created Successfully......");
				break;
			case 2:
				try {
					serviceImpl.ShowBalnce();
				} catch (AccountNotFoundException e) {
					System.out.println("\n\nAccount Not Found");
				}
				break;
			case 3:
				try {
					serviceImpl.deposite();
				} catch (AccountNotFoundException e) {
					System.out.println("\n\nAccount Not Found");
				}catch (InsufficientAmountException e) {
					System.out.println("\n\nAmount is Not Sufficient for transaction");
				}
				break;
			case 4:
				try {
					serviceImpl.withdraw();
				} catch (AccountNotFoundException e) {
					System.out.println("\n\nAccount Not Found");
				}catch (InsufficientAmountException e) {
					System.out.println("\n\nAmount is Not Sufficient for transaction");
				}
				break;
			case 5:
				try {
					serviceImpl.fundTransfer();
				} catch (AccountNotFoundException e) {
					System.out.println("\n\nAccount Not Found");
				} catch (InsufficientAmountException e) {
					System.out.println("\n\nAmount is Not Sufficient for transaction");
				}
				break;
			case 6:
				try {
					serviceImpl.printTransaction();
				} catch (AccountNotFoundException e) {
					System.out.println("\n\nAccount Not Found");
				}
				break;
			default:
				System.out.println("Exit");
				System.exit(0);
			}
		}while (choice != 7);
		scan.close();
	}
}
